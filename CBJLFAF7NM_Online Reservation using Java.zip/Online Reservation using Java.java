import java.util.*;
import java.time.LocalDate;
class Reservation {
    private int id;
    private String name;
    private LocalDate date;
    private int numberOfGuests;

    public Reservation(int id, String name, LocalDate date, int numberOfGuests) {
        this.id = id;
        this.name = name;
        this.date = date;
        this.numberOfGuests = numberOfGuests;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public LocalDate getDate() {
        return date;
    }

    public int getNumberOfGuests() {
        return numberOfGuests;
    }

    // Main method to test Reservation class
    public static void main(String[] args) {
        Reservation reservation = new Reservation(1, "John Doe", LocalDate.of(2024, 9, 10), 4);
        System.out.println("Reservation Details:");
        System.out.println("ID: " + reservation.getId());
        System.out.println("Name: " + reservation.getName());
        System.out.println("Date: " + reservation.getDate());
        System.out.println("Number of Guests: " + reservation.getNumberOfGuests());
    }
}
class ReservationSystem {
    private List<Reservation> reservations = new ArrayList<>();
    private int nextId = 1;

    public Reservation makeReservation(String name, LocalDate date, int numberOfGuests) {
        Reservation reservation = new Reservation(nextId++, name, date, numberOfGuests);
        reservations.add(reservation);
        return reservation;
    }

    public List<Reservation> getReservations() {
        return reservations;
    }

    public Reservation getReservationById(int id) {
        for (Reservation reservation : reservations) {
            if (reservation.getId() == id) {
                return reservation;
            }
        }
        return null;
    }

    public boolean cancelReservation(int id) {
        Reservation reservation = getReservationById(id);
        if (reservation != null) {
            reservations.remove(reservation);
            return true;
        }
        return false;
    }

    // Main method to test ReservationSystem class
    public static void main(String[] args) {
        ReservationSystem system = new ReservationSystem();
        LocalDate date = LocalDate.of(2024, 9, 10);

        // Make reservations
        Reservation r1 = system.makeReservation("Alice", date, 2);
        Reservation r2 = system.makeReservation("Bob", date, 3);

        // Print reservations
        System.out.println("All Reservations:");
        for (Reservation r : system.getReservations()) {
            System.out.println(r.getId() + " - " + r.getName() + " - " + r.getDate() + " - " + r.getNumberOfGuests());
        }

        // Cancel a reservation
        System.out.println("Cancelling Reservation ID 1...");
        if (system.cancelReservation(1)) {
            System.out.println("Reservation canceled successfully.");
        } else {
            System.out.println("Reservation not found.");
        }

        // Print reservations again
        System.out.println("All Reservations after cancellation:");
        for (Reservation r : system.getReservations()) {
            System.out.println(r.getId() + " - " + r.getName() + " - " + r.getDate() + " - " + r.getNumberOfGuests());
        }
    }
}